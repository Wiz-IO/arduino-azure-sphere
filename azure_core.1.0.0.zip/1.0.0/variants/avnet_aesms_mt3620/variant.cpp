/*
 *  Created on: 01.01.2019
 *      Author: Georgi Angelov
 */

#include <Arduino.h>
#include <avnet_aesms_mt3620.h>

HardwareSerial Serial(AVNET_AESMS_ISU0_UART); 
