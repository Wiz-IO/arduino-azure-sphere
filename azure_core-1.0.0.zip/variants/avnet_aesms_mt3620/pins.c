
#include "variant.h"

PinDescription pinsMap[PINS_MAX] = {
    {0, 0, -1, NULL},
    {1, 1, -1, NULL},
    {2, 2, -1, NULL},
    {3, 3, -1, NULL},
    {4, 4, -1, NULL},
    {5, 5, -1, NULL},
    {6, 6, -1, NULL},
    {7, 7, -1, NULL},
    {8, 8, -1, NULL},
    {9, 9, -1, NULL},

    /* TODO OTHER */
};