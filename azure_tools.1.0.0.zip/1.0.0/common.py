# WizIO 2019 Georgi Angelov
# http://www.wizio.eu/
# https://github.com/Wiz-IO

import os, sys, json, shutil, uuid
from shutil import copyfile
from os.path import join, normpath, basename
from subprocess import check_output, CalledProcessError, call, Popen, PIPE

def execute(cmd):
    proc = Popen(cmd, stdout=PIPE, stderr=PIPE)
    out, err = proc.communicate()
    a = out.decode().split("\r\n")
    for i in range(len(a)):
        print( a[i].replace("\r\n", "") )
    if proc.returncode != 0:
        exit(1)
    return proc.returncode 

def dev_copy_json(env):
    copyfile(
        join(env["CORES_DIR"], "..","..", "variants", env["VARIANT"], "mt3620.json"), 
        join(env["BUILD_DIR"], "approot", "mt3620.json")
    )
    file = env["VARIANT"] + ".json"
    copyfile(
        join(env["CORES_DIR"], "..", "..", "variants", env["VARIANT"], file), 
        join(env["BUILD_DIR"], "approot", file)
    )
    src = join(env["PROJECT_DIR"], "app_manifest.json")
    dst = join(env["BUILD_DIR"], "approot", "app_manifest.json")
    copyfile(src, dst)
    U = str(uuid.uuid4()).upper()  
    print ('UUID: ', U)
    with open(dst, 'r+') as f:
        data = json.load(f)
        data['ComponentId'] = U                                                             # change this
        data['Name'] = "APP_" + basename( normpath( env["PROJECT_DIR"] ) ).replace(" ", "") # change this ProjectName
        data['EntryPoint'] = "/bin/app"                                                     # change this
        f.seek(0)        
        json.dump(data, f, indent=4)
        f.truncate()  

def remove_contents(path):
    for c in os.listdir(path):
        full_path = os.path.join(path, c)
        if os.path.isfile(full_path):
            os.remove(full_path)
        else:
            shutil.rmtree(full_path)
    try: os.remove(path)     
    except: pass            

def dev_pack_image(env):
    approot = join(env["BUILD_DIR"], "approot") 
    bin = join(approot, "bin")
    if True == os.path.isdir(approot):
        remove_contents(approot)  
    if False == os.path.isdir(approot):
        os.makedirs(approot)   
    if False == os.path.isdir(bin):
        os.makedirs(bin)       

    copyfile(join(env["BUILD_DIR"], env["PROJECT_NAME"]+".ino.elf"), join(bin, "app"))
    dev_copy_json(env)
    cmd = []
    cmd.append( join(env["SDK"], "Tools",  "azsphere") ) 
    cmd.append("image")
    cmd.append("package-application")
    cmd.append("--input")
    cmd.append( join( env["BUILD_DIR"], "approot" ) ) 
    cmd.append("--output")
    cmd.append( join(env["BUILD_DIR"], "approot","app.image") )
    cmd.append("--sysroot")
    cmd.append( env["SYSROOT"] )
    #cmd.append("--verbose")
    cmd.append("--hardwaredefinition")
    cmd.append( join(env["BUILD_DIR"], "approot", env["VARIANT"] + ".json" ) ) # avnet_aesms_mt3620.json
    return execute(cmd)  


def get_project_dir(BUILD_DIR):
    with open(join(BUILD_DIR, "build.options.json"), 'r+') as f:
        data = json.load( f )
        PROJECT_DIR = os.path.dirname( os.path.abspath( data['sketchLocation'] ) )
        PROJECT_NAME = basename( normpath( data['sketchLocation'] ) ).replace(" ", "").replace(".ino", "") 
        return PROJECT_DIR, PROJECT_NAME
