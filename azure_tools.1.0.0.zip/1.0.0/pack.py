# WizIO 2019 Georgi Angelov
# http://www.wizio.eu/
# https://github.com/Wiz-IO

import os, sys
from os.path import join
from common import *

print("-------------------- PACKING IMAGE --------------------")
if len(sys.argv) < 5:
    exit(1)
build_dir = sys.argv[1]
project_dir, project_name = get_project_dir(build_dir)   
env = {
    'TOOLS_DIR'     : os.path.dirname( os.path.abspath( sys.argv[0] ) ),
    'BUILD_DIR'     : build_dir,
    'CORES_DIR'     : sys.argv[2],
    'SDK'           : join(sys.argv[3], "..", ".."),
    'SYSROOT'       : basename( normpath(sys.argv[3]) ),
    'PROJECT_DIR'   : project_dir,
    'PROJECT_NAME'  : project_name,
    'VARIANT'       : sys.argv[4],
}
exit( dev_pack_image(env) )

