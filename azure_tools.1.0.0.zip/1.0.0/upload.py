# WizIO 2019 Georgi Angelov
# http://www.wizio.eu/
# https://github.com/Wiz-IO

import os, sys
from os.path import join
from common import *

def dev_uploader(env):
    cmd = []
    cmd.append( join(env["SDK"], "Tools",  "azsphere") )
    cmd.append("device")
    cmd.append("sideload")
    cmd.append("delete")
    if (0 == execute(cmd)):
        print ('OLD APPLICATION IS REMOVED')
    else: return
    cmd = []        
    cmd.append( join(env["SDK"], "Tools",  "azsphere") ) 
    cmd.append("device")
    cmd.append("sideload")
    cmd.append("deploy")
    cmd.append("--imagepackage")
    cmd.append(join(env["BUILD_DIR"], "app.image"))
    rc = execute(cmd)
    if (0 == rc):
        print ('NEW APPLICATION IS READY')
    return rc

print("-------------------- UPLOADING --------------------")
if len(sys.argv) < 2:
    exit(1)
build_dir = sys.argv[1]
project_dir, project_name = get_project_dir(build_dir)   
env = {
    'BUILD_DIR'     : build_dir,
    'SDK'           : join(sys.argv[2], "..", ".."),
    'PROJECT_NAME'  : project_name,
}       
exit( dev_uploader(env) ) 